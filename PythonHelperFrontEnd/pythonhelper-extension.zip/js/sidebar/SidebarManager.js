// js/sidebar/SidebarManager.js

import { UIManager } from './UIManager.js';
import { ChatManager } from './ChatManager.js';
// 导入 SettingsManager 来处理设置逻辑
import { SettingsManager } from './SettingsManager.js';

class SidebarManager {
    constructor() {
        this.ui = new UIManager();
        this.chatManager = new ChatManager(this.ui);
        // 新增：实例化 SettingsManager
        this.settingsManager = new SettingsManager(this.ui);
        
        // 验证码发送状态跟踪
        this.verificationStatus = {
            register: { sent: false, email: null },
            reset: { sent: false, email: null }
        };

        this.bindEvents();
        this.init();
    }

    async init() {
        await this.chatManager.init();
        await this.settingsManager.init();
        await this.checkLoginStatus();
    }
    
    bindEvents() {
        // --- 聊天相关事件 ---
        this.ui.welcomeScreen.querySelector('#startFirstChat').addEventListener('click', () => this.chatManager.createNewChat());
        this.ui.sendMessageBtn.addEventListener('click', (e) => { e.preventDefault(); this.chatManager.sendMessage(this.ui.chatInput.value.trim()); });
        this.ui.chatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.chatManager.sendMessage(this.ui.chatInput.value.trim());
            }
        });
        this.ui.chatInput.addEventListener('input', () => this.ui.adjustTextareaHeight());
        document.getElementById('clearChatBtn').addEventListener('click', () => this.chatManager.clearCurrentChat());

        // --- 错题事件绑定 ---
        document.getElementById('enterMistakeModeBtn').addEventListener('click', () => this.chatManager.toggleMistakeSelectionMode());
        document.getElementById('saveSelectionBtn').addEventListener('click', () => this.chatManager.saveSelectionToMistakes());
        this.ui.chatMessages.addEventListener('change', (e) => {
            if (e.target.classList.contains('message-selector')) {
                const messageElement = e.target.closest('.message');
                const messageId = messageElement.dataset.messageId;
                this.chatManager.handleMessageSelection(messageId, e.target.checked);
            }
        });

        // --- 图标与视图切换事件 ---
        document.getElementById('toggleChatListBtn').addEventListener('click', () => this.ui.toggleChatList());
        document.getElementById('newChatBtn').addEventListener('click', () => this.chatManager.createNewChat());
        
        // 登录按钮事件绑定 - 添加调试
        const loginBtn = document.getElementById('loginBtn');
        const loginFromSidebar = document.getElementById('loginFromSidebar');
        
        if (loginBtn) {
            loginBtn.addEventListener('click', () => {
                this.handleLogin();
            });
        }
        
        if (loginFromSidebar) {
            loginFromSidebar.addEventListener('click', () => {
                this.handleLogin();
            });
        }
        
        document.getElementById('mistakesBtn').addEventListener('click', () => this.chatManager.showMistakeCollection());
        
        // --- 设置事件绑定 ---
        document.getElementById('settingsBtn').addEventListener('click', () => this.ui.showView(this.ui.settingsInterface));
        this.ui.settingsInterface.querySelector('#saveSettings').addEventListener('click', () => this.handleSaveSettings());

        // --- PTA题目分析事件绑定 ---
        document.getElementById('ptaBtn').addEventListener('click', () => this.ui.showView(this.ui.ptaAnalysisInterface));
        document.getElementById('startPtaAnalysisBtn').addEventListener('click', () => this.handlePtaAnalysis());
        
        // --- 返回按钮事件 ---
        this.bindBackButtons();
        
        // --- 登录界面事件绑定 ---
        this.bindAuthEvents();
        
        // 打开错题管理器页面的按钮
        const openMistakeManagerBtn = document.getElementById('openMistakeManagerBtn');
        if(openMistakeManagerBtn) {
            openMistakeManagerBtn.addEventListener('click', () => {
                 chrome.tabs.create({ url: chrome.runtime.getURL('html/mistake_manager.html') });
            });
        }
    }

    // 新增：处理PTA分析请求
    handlePtaAnalysis() {
        const urlInput = document.getElementById('ptaUrlInput');
        const url = urlInput.value.trim();

        if (!url.startsWith('https://pintia.cn/problem-sets/')) {
            alert('请输入一个有效的拼题A题目集网址！');
            return;
        }

        const analysisBtn = document.getElementById('startPtaAnalysisBtn');
        analysisBtn.textContent = '分析中...';
        analysisBtn.disabled = true;

        console.log('正在请求后台脚本进行PTA分析...');
        chrome.runtime.sendMessage({ type: 'FETCH_PTA_DATA', url: url }, (response) => {
            analysisBtn.textContent = '开始分析';
            analysisBtn.disabled = false;
            
            if (response && response.status === 'success') {
                console.log('成功接收到HTML报告，正在打开新标签页...');
                // response.data 现在是HTML字符串
                const reportHtml = response.data;
                const blob = new Blob([reportHtml], { type: 'text/html' });
                const reportUrl = URL.createObjectURL(blob);
                chrome.tabs.create({ url: reportUrl });
                
                // 成功后可以返回主界面
                this.showMainView();
            } else {
                alert(`分析失败: ${response ? response.error : '未知错误'}`);
            }
        });
    }

    // 新增：处理保存设置的逻辑
    async handleSaveSettings() {
        const newSettings = await this.settingsManager.saveSettings();
        if (newSettings) {
            // 通知 ChatManager 更新其内部的 settings
            this.chatManager.updateSettings(newSettings);
            // 通知 background script
            chrome.runtime.sendMessage({ type: 'SETTINGS_UPDATED', settings: newSettings });
        }
    }
    
    // 辅助方法，用于确定返回的主视图
    showMainView() {
        if (this.chatManager.chats.length > 0) {
            this.chatManager.showChat(this.chatManager.currentChatId || this.chatManager.chats[0].id);
        } else {
            this.ui.showView(this.ui.welcomeScreen);
        }
    }

    // 辅助方法，用于绑定所有返回按钮
    bindBackButtons() {
        const backToMain = () => {
           this.showMainView();
        };
        document.getElementById('backToMain').addEventListener('click', backToMain);
        document.getElementById('backToMainFromSettings').addEventListener('click', backToMain);
        document.getElementById('backToMainFromPta').addEventListener('click', backToMain); // 新增
        document.getElementById('backToMainFromLogin').addEventListener('click', backToMain);
    }

    // 检查登录状态
    async checkLoginStatus() {
        try {
            const result = await chrome.storage.local.get(['isLoggedIn', 'userEmail']);
            this.updateUIBasedOnLoginStatus(result.isLoggedIn, result.userEmail);
        } catch (error) {
            console.error('检查登录状态失败:', error);
            this.updateUIBasedOnLoginStatus(false, null);
        }
    }

    // 根据登录状态更新UI
    updateUIBasedOnLoginStatus(isLoggedIn, userEmail) {
        const loginPrompt = document.getElementById('loginPrompt');
        const startFirstChat = document.getElementById('startFirstChat');
        const loginBtn = document.getElementById('loginBtn');
        
        // 需要登录后才能使用的按钮
        const requireLoginButtons = [
            'mistakesBtn', 'settingsBtn', 'ptaAnalysisBtn',
            'openMistakeManagerBtn', 'toggleChatListBtn'
        ];
        
        if (isLoggedIn && userEmail) {
            // 用户已登录 - 启用所有功能
            loginPrompt.style.display = 'none';
            startFirstChat.disabled = false;
            startFirstChat.textContent = '开始对话';
            startFirstChat.style.opacity = '1';
            
            // 启用所有功能按钮
            requireLoginButtons.forEach(btnId => {
                const btn = document.getElementById(btnId);
                if (btn) {
                    btn.disabled = false;
                    btn.style.opacity = '1';
                    btn.style.pointerEvents = 'auto';
                }
            });
            
            // 更新登录按钮显示
            loginBtn.innerHTML = '<span class="material-symbols-outlined">account_circle</span>';
            loginBtn.title = `已登录: ${userEmail}`;
            loginBtn.style.background = 'rgba(76, 175, 80, 0.3)';
            
            // 添加右键菜单功能
            loginBtn.addEventListener('contextmenu', (e) => {
                e.preventDefault();
                if (confirm(`当前登录: ${userEmail}\n\n点击确定退出登录`)) {
                    this.handleLogout();
                }
            });
        } else {
            // 用户未登录 - 只显示登录界面
            loginPrompt.style.display = 'block';
            startFirstChat.disabled = true;
            startFirstChat.textContent = '需要先登录';
            startFirstChat.style.opacity = '0.5';
            
            // 禁用所有功能按钮
            requireLoginButtons.forEach(btnId => {
                const btn = document.getElementById(btnId);
                if (btn) {
                    btn.disabled = true;
                    btn.style.opacity = '0.5';
                    btn.style.pointerEvents = 'none';
                }
            });
            
            // 重置登录按钮显示
            loginBtn.innerHTML = '<span class="material-symbols-outlined">login</span>';
            loginBtn.title = '点击登录';
            loginBtn.style.background = '';
        }
    }

    // 处理登录按钮点击
    handleLogin() {
        // 显示登录界面
        this.ui.showView(this.ui.loginInterface);
    }

    // 处理退出登录
    async handleLogout() {
        try {
            await chrome.storage.local.remove(['isLoggedIn', 'userEmail', 'userToken']);
            await this.checkLoginStatus();
        } catch (error) {
            console.error('退出登录失败:', error);
        }
    }

    // 绑定认证界面事件
    bindAuthEvents() {
        // 登录/注册标签切换
        document.getElementById('loginTab').addEventListener('click', () => this.showAuthForm('login'));
        document.getElementById('registerTab').addEventListener('click', () => this.showAuthForm('register'));
        
        // 忘记密码链接
        document.getElementById('forgotPasswordLink').addEventListener('click', (e) => {
            e.preventDefault();
            this.showAuthForm('forgot');
        });
        document.getElementById('backToLoginLink').addEventListener('click', (e) => {
            e.preventDefault();
            this.showAuthForm('login');
        });
        
        // 表单提交
        document.getElementById('loginSubmitBtn').addEventListener('click', () => this.handleLoginSubmit());
        document.getElementById('registerSubmitBtn').addEventListener('click', () => this.handleRegisterSubmit());
        document.getElementById('resetPasswordSubmitBtn').addEventListener('click', () => this.handleResetPasswordSubmit());
        
        // 发送验证码
        document.getElementById('sendVerificationBtn').addEventListener('click', () => this.handleSendVerification());
        document.getElementById('sendResetCodeBtn').addEventListener('click', () => this.handleSendResetCode());
        
        // 回车键提交
        ['loginEmail', 'loginPassword'].forEach(id => {
            document.getElementById(id).addEventListener('keypress', (e) => {
                if (e.key === 'Enter') this.handleLoginSubmit();
            });
        });
    }

    // 显示指定的认证表单
    showAuthForm(type) {
        const forms = ['loginForm', 'registerForm', 'forgotPasswordForm'];
        const tabs = ['loginTab', 'registerTab'];
        
        // 隐藏所有表单
        forms.forEach(formId => {
            const form = document.getElementById(formId);
            if (form) form.classList.add('hidden');
        });
        
        // 移除所有标签的激活状态
        tabs.forEach(tabId => {
            const tab = document.getElementById(tabId);
            if (tab) tab.classList.remove('active');
        });
        
        // 显示指定表单和标签
        if (type === 'login') {
            document.getElementById('loginForm').classList.remove('hidden');
            document.getElementById('loginTab').classList.add('active');
        } else if (type === 'register') {
            document.getElementById('registerForm').classList.remove('hidden');
            document.getElementById('registerTab').classList.add('active');
        } else if (type === 'forgot') {
            document.getElementById('forgotPasswordForm').classList.remove('hidden');
        }
        
        // 清空消息
        this.showAuthMessage('');
    }

    // 显示认证消息
    showAuthMessage(message, type = 'info') {
        const messageEl = document.getElementById('authMessage');
        if (!message) {
            messageEl.classList.add('hidden');
            return;
        }
        
        messageEl.className = `auth-message ${type}`;
        messageEl.textContent = message;
        messageEl.classList.remove('hidden');
    }

    // 处理登录提交
    async handleLoginSubmit() {
        const email = document.getElementById('loginEmail').value.trim();
        const password = document.getElementById('loginPassword').value.trim();
        
        if (!this.validateEmail(email)) return;
        if (!password) {
            this.showAuthMessage('请输入密码', 'error');
            return;
        }
        
        const btn = document.getElementById('loginSubmitBtn');
        const originalText = btn.textContent;
        btn.textContent = '登录中...';
        btn.disabled = true;
        
        try {
            const response = await fetch('http://47.98.249.0:8888/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });
            
            const result = await response.json();
            
            if (result.status === 'success') {
                await chrome.storage.local.set({
                    isLoggedIn: true,
                    userEmail: email,
                    userToken: result.token || 'temp'
                });
                
                this.showAuthMessage('登录成功！', 'success');
                setTimeout(() => {
                    this.showMainView();
                    this.checkLoginStatus();
                }, 1500);
            } else {
                this.showAuthMessage(result.message || '登录失败', 'error');
            }
        } catch (error) {
            this.showAuthMessage('网络错误，请稍后重试', 'error');
        }
        
        btn.textContent = originalText;
        btn.disabled = false;
    }

    // 处理注册提交
    async handleRegisterSubmit() {
        const email = document.getElementById('registerEmail').value.trim();
        const code = document.getElementById('verificationCode').value.trim();
        const password = document.getElementById('registerPassword').value.trim();
        const confirmPassword = document.getElementById('confirmPassword').value.trim();
        
        if (!this.validateEmail(email)) return;
        
        // 检查是否已发送验证码
        if (!this.verificationStatus.register.sent || this.verificationStatus.register.email !== email) {
            this.showAuthMessage('请先点击"发送验证码"获取邮箱验证码', 'error');
            return;
        }
        
        if (!code) {
            this.showAuthMessage('请输入验证码', 'error');
            return;
        }
        if (!password) {
            this.showAuthMessage('请输入密码', 'error');
            return;
        }
        if (password !== confirmPassword) {
            this.showAuthMessage('两次输入的密码不一致', 'error');
            return;
        }
        
        const btn = document.getElementById('registerSubmitBtn');
        const originalText = btn.textContent;
        btn.textContent = '注册中...';
        btn.disabled = true;
        
        try {
            const response = await fetch('http://47.98.249.0:8888/auth/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, verification_code: code, password })
            });
            
            const result = await response.json();
            
            if (result.status === 'success') {
                this.showAuthMessage('注册成功！请登录', 'success');
                setTimeout(() => {
                    this.showAuthForm('login');
                    document.getElementById('loginEmail').value = email;
                }, 1500);
            } else {
                this.showAuthMessage(result.message || '注册失败', 'error');
            }
        } catch (error) {
            this.showAuthMessage('网络错误，请稍后重试', 'error');
        }
        
        btn.textContent = originalText;
        btn.disabled = false;
    }

    // 处理密码重置提交
    async handleResetPasswordSubmit() {
        const email = document.getElementById('resetEmail').value.trim();
        const code = document.getElementById('resetVerificationCode').value.trim();
        const newPassword = document.getElementById('newPassword').value.trim();
        const confirmNewPassword = document.getElementById('confirmNewPassword').value.trim();
        
        if (!this.validateEmail(email)) return;
        
        // 检查是否已发送验证码
        if (!this.verificationStatus.reset.sent || this.verificationStatus.reset.email !== email) {
            this.showAuthMessage('请先点击"发送验证码"获取邮箱验证码', 'error');
            return;
        }
        
        if (!code) {
            this.showAuthMessage('请输入验证码', 'error');
            return;
        }
        if (!newPassword) {
            this.showAuthMessage('请输入新密码', 'error');
            return;
        }
        if (newPassword !== confirmNewPassword) {
            this.showAuthMessage('两次输入的密码不一致', 'error');
            return;
        }
        
        const btn = document.getElementById('resetPasswordSubmitBtn');
        const originalText = btn.textContent;
        btn.textContent = '重置中...';
        btn.disabled = true;
        
        try {
            const response = await fetch('http://47.98.249.0:8888/auth/reset-password', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    email, 
                    verification_code: code, 
                    new_password: newPassword 
                })
            });
            
            const result = await response.json();
            
            if (result.status === 'success') {
                this.showAuthMessage('密码重置成功！请登录', 'success');
                setTimeout(() => {
                    this.showAuthForm('login');
                    document.getElementById('loginEmail').value = email;
                }, 1500);
            } else {
                this.showAuthMessage(result.message || '密码重置失败', 'error');
            }
        } catch (error) {
            this.showAuthMessage('网络错误，请稍后重试', 'error');
        }
        
        btn.textContent = originalText;
        btn.disabled = false;
    }

    // 发送验证码（注册）
    async handleSendVerification() {
        const email = document.getElementById('registerEmail').value.trim();
        if (!this.validateEmail(email)) return;
        
        const btn = document.getElementById('sendVerificationBtn');
        const originalText = btn.textContent;
        let countdown = 60;
        
        btn.textContent = `${countdown}s`;
        btn.disabled = true;
        
        const countdownInterval = setInterval(() => {
            countdown--;
            btn.textContent = `${countdown}s`;
            if (countdown <= 0) {
                clearInterval(countdownInterval);
                btn.textContent = originalText;
                btn.disabled = false;
            }
        }, 1000);
        
        try {
            const response = await fetch('http://47.98.249.0:8888/auth/send-verification', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email })
            });
            
            const result = await response.json();
            
            if (result.status === 'success') {
                this.verificationStatus.register.sent = true;
                this.verificationStatus.register.email = email;
                this.showAuthMessage('验证码已发送，请查收邮件', 'success');
            } else {
                this.showAuthMessage(result.message || '发送失败', 'error');
            }
        } catch (error) {
            this.showAuthMessage('网络错误，请稍后重试', 'error');
        }
    }

    // 发送重置密码验证码
    async handleSendResetCode() {
        const email = document.getElementById('resetEmail').value.trim();
        if (!this.validateEmail(email)) return;
        
        const btn = document.getElementById('sendResetCodeBtn');
        const originalText = btn.textContent;
        let countdown = 60;
        
        btn.textContent = `${countdown}s`;
        btn.disabled = true;
        
        const countdownInterval = setInterval(() => {
            countdown--;
            btn.textContent = `${countdown}s`;
            if (countdown <= 0) {
                clearInterval(countdownInterval);
                btn.textContent = originalText;
                btn.disabled = false;
            }
        }, 1000);
        
        try {
            const response = await fetch('http://47.98.249.0:8888/auth/forgot-password', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email })
            });
            
            const result = await response.json();
            
            if (result.status === 'success') {
                this.verificationStatus.reset.sent = true;
                this.verificationStatus.reset.email = email;
                this.showAuthMessage('验证码已发送，请查收邮件', 'success');
            } else {
                this.showAuthMessage(result.message || '发送失败', 'error');
            }
        } catch (error) {
            this.showAuthMessage('网络错误，请稍后重试', 'error');
        }
    }

    // 验证邮箱格式
    validateEmail(email) {
        if (!email) {
            this.showAuthMessage('请输入邮箱地址', 'error');
            return false;
        }
        if (!email.endsWith('@zju.edu.cn')) {
            this.showAuthMessage('请输入@zju.edu.cn域名的邮箱地址', 'error');
            return false;
        }
        return true;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new SidebarManager();
});